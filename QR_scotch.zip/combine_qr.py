from PIL import Image

img = Image.new('RGB', (340, 336))

img1 = Image.open('D:/QR_code/image/qr_code_1.png')
img2 = Image.open('D:/QR_code/image/qr_code_2.png')

img.paste(img1, (0, 0))
img.paste(img2, (170, 0))


img.show()
img.save("out.jpg")